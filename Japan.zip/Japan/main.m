//
//  main.m
//  Japan
//
//  Created by PANCHAM GUPTA on 6/26/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, @"JapanAppDelegate");
    [pool release];
    return retVal;
}

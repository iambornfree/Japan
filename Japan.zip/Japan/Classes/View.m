//
//  View.m
//  Japan
//
//  Created by PANCHAM GUPTA on 6/26/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "View.h"


@implementation View

- (id) initWithFrame: (CGRect) frame {
	if ((self = [super initWithFrame: frame]) != nil) {
		// Initialization code
		self.backgroundColor = [UIColor whiteColor];
		
		//Keep the size of the view the same,
		//but let the center of the view be the origin.
		//CGFloat w = self.bounds.size.width;
		//CGFloat h = self.bounds.size.height;
		//self.bounds = CGRectMake(-w / 2, -h / 2, w, h);
	}
	return self;
}


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.

- (void) drawRect: (CGRect) rect {
	CGRect b = self.bounds;
	CGRect f = self.frame;

	NSLog(@"self.frame == (%g, %g), %g × %g",
		  f.origin.x,
		  f.origin.y,
		  f.size.width,
		  f.size.height
		  );
	
	NSLog(@"self.bounds == (%g, %g), %g × %g",
		  b.origin.x,
		  b.origin.y,
		  b.size.width,
		  b.size.height
		  );

	// radius in pixels
	CGFloat radius = .3 * b.size.width;	//in pixels
	
	// draw japan flag
	[self drawRectJapan:radius];
	
}

- (void) displayText:(NSString *)text 
			 AtPoint: (CGPoint) point
			WithFont: (UIFont *) font
{
	[text drawAtPoint:point withFont:font];
}


- (void) drawRectJapan:(CGFloat) radius
{
	// japan code.
	
	/*
	 Create the invisible square that will surround the circle.
	 Place the upper left corner of the square at the upper left corner of
	 the View.  b.origin.x and b.origin.y are the coordinates of the upper
	 left corner of the View.
	 */
	CGRect r = CGRectMake(
						  -radius,
						  -radius,
						  2 * radius,
						  2 * radius
						  );
	CGSize size = self.bounds.size;
	CGContextRef c = UIGraphicsGetCurrentContext();
		
	CGContextBeginPath(c);
	CGContextTranslateCTM(c, size.width / 2, size.height / 2); //origin at center of view
	CGContextAddEllipseInRect(c, r);
	CGContextSetRGBFillColor(c, 1.0, 0.0, 0.0, 1.0);	//red, opaque
	CGContextFillPath(c);	
	
	// figure out text and location
	NSString *text = NSLocalizedString(@"Country", @"name of the country");
	UIFont *font = [UIFont systemFontOfSize:50];
	CGSize textSize = [text sizeWithFont:font];
	CGFloat x = -textSize.width/2;
	CGFloat y = radius;// + textSize.height/2;
	CGPoint point = CGPointMake(x, y);
	
	// draw text 
	[self displayText: text
			  AtPoint: point 
			 WithFont: font];
	
}

- (void) drawRectRedCross
{
	// Drawing code
	//Fill the Red Cross.
	CGSize size = self.bounds.size;
	CGFloat min = MIN(size.width, size.height);
	CGFloat longSide = min * 15 / 16;
	CGFloat shortSide = longSide / 3;
	
	CGContextRef c = UIGraphicsGetCurrentContext();
	
	CGContextBeginPath(c);
	
	CGContextTranslateCTM(c, size.width / 2, size.height / 2); //origin at center of view
	CGContextRotateCTM(c, -15.0 * M_PI / 180.0);
	
	CGContextScaleCTM(c, 1, -1);                               //make Y axis point up
	
	CGRect horizontal = CGRectMake(-longSide / 2, -shortSide / 2, longSide, shortSide);
	CGRect   vertical = CGRectMake(-shortSide / 2, -longSide / 2, shortSide, longSide);
	CGContextAddRect(c, horizontal);
	CGContextAddRect(c, vertical);
	
	CGContextSetRGBFillColor(c, 1.0, 0.0, 0.0, 1.0);
	CGContextFillPath(c);
}

- (void) drawRectTriangle
{
	//Fill a right triangle.
	CGSize size = self.bounds.size;
	CGFloat min = MIN(size.width, size.height);
	CGFloat length = min * 5 / 8;           //of side
	
	
	// create a path with the two lines ready.
	CGMutablePathRef p = CGPathCreateMutable();
	CGPathMoveToPoint(p, NULL, 0, 0);
	CGPathAddLineToPoint(p, NULL, 0, length);
	CGPathAddLineToPoint(p, NULL, -length, 0);
	CGPathCloseSubpath(p);
	
	
	CGContextRef c = UIGraphicsGetCurrentContext();
	//origin at right angle
	CGContextTranslateCTM(c,
						  (size.width + length) / 2,
						  (size.height + length) / 2
						  );
	CGContextScaleCTM(c, 1, -1);
	
	CGContextBeginPath(c);
	CGContextAddPath(c, p);
	CGContextSetRGBFillColor(c, 1, 0, 0, 1);
	//Light source at upper left, shadow at lower right.
	CGSize shadow = CGSizeMake(5, 20);
	
	//5 is the amount of blur.  A smaller number makes a sharper shadow.
	CGContextSetShadow(c, shadow, 5);
	CGContextFillPath(c);	
	
	CGContextBeginPath(c);
	CGContextAddPath(c, p);
	CGContextSetLineWidth(c, 10);
	CGContextSetRGBStrokeColor(c, 0, 0, 1, 1);
	//Light source at upper left, shadow at lower right.
	//CGSize shadow = CGSizeMake(10, 20);
	
	//5 is the amount of blur.  A smaller number makes a sharper shadow.
	CGContextSetShadow(c, shadow, 5);
	CGContextStrokePath(c);
	CGPathRelease(p);
}



- (void) dealloc {
	[super dealloc];
}

@end

//
//  View.h
//  Japan
//
//  Created by PANCHAM GUPTA on 6/26/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//
#import <UIKit/UIKit.h>


@interface View: UIView {
}

// TODO: Make these private. But how?
- (void) drawRectTriangle;
- (void) drawRectJapan:(CGFloat) radius;
- (void) drawRectRedCross;
- (void) displayText: (NSString *)text 
			 AtPoint: (CGPoint) point
			WithFont: (UIFont*) font;
@end
